DELETE FROM `#__content_types` WHERE `type_alias` IN ('com_agdetagsearchs.agdetagsearch', 'com_agdetagsearchs.category');

DROP TABLE IF EXISTS `#__agdetagsearchs`;
