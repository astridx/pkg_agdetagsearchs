/**
 * @subpackage  Agdetagsearch
 *
 * @copyright   Copyright (C) 2017 Astrid Günther & Dimitry Engbert All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
