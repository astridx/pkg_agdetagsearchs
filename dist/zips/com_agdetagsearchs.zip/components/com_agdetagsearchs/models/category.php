<?php
/**
 * @subpackage  Agdetagsearch
 *
 * @copyright   Copyright (C) 2018 Astrid Günther & Dimitry Engbert All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\Registry\Registry;

/**
 * Agdetagsearchs Component Agdetagsearch Model
 *
 * @since  1.5
 */
class AgdetagsearchsModelCategory extends JModelList
{
	/**
	 * Agdetagsearch data array
	 *
	 * @var array
	 */
	protected $_data = null;

	/**
	 * Agdetagsearch total
	 *
	 * @var integer
	 */
	protected $_total = null;

	/**
	 * Category items data
	 *
	 * @var array
	 */
	protected $_item = null;

	/**
	 * Category items articles
	 *
	 * @var array
	 */
	protected $_articles = null;

	/**
	 * Category items siblins
	 *
	 * @var array
	 */
	protected $_siblings = null;

	/**
	 * Category items children
	 *
	 * @var array
	 */
	protected $_children = null;

	/**
	 * Category items parent
	 *
	 * @var array
	 */
	protected $_parent = null;

	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @see     JControllerLegacy
	 * @since   1.6
	 */
	public function __construct($config = array())
	{

		parent::__construct($config);

		// Get configuration
		$app = JFactory::getApplication();
		$config = JFactory::getConfig();

		// Get the pagination request variables
		$this->setState('limit', $app->input->getString('limit'));
		$this->setState('limitstart', $app->input->get('limitstart', 0, 'uint'));

		$this->setState('typesr', $app->input->getString('contenttype'));
		$this->setState('language', $app->input->getString('agde_language'));
		$this->setState('limit', $app->input->getString('limit'));
		$this->setState('agtagscolumnlimit', $app->input->getString('agtagscolumnlimit'));
		$this->setState('agtagscolumnlimit_fields', $app->input->getString('agtagscolumnlimit_fields'));

		$this->items = $this->getItems();

		foreach ($this->items as $item)
		{
			$postvalue = 'agdetagsearchs_' . str_replace(' ', '', $item->alias);
			$value1 = $app->input->getString($postvalue);

			if (isset($value1))
			{
				$this->setState($postvalue, $value1);
			}
		}
	}

	/**
	 * The category that applies.
	 *
	 * @var  object
	 */
	protected $_category = null;

	/**
	 * The list of other agdetagsearch categories.
	 *
	 * @var  array
	 */
	protected $_categories = null;

	/**
	 * Method to get a list of items.
	 *
	 * @return  mixed  An array of objects on success, false on failure.
	 */
	public function getItems()
	{
		// Invoke the parent getItems method to get the main list
		$items = parent::getItems();

		// Convert the params field into an object, saving original in _params
		foreach ($items as $item)
		{
			if (!isset($this->_params))
			{
				$params = new Registry;
				$params->loadString($item->params);
				$item->params = $params;
			}

			// Get the tags
			$item->tags = new JHelperTags;
			$item->tags->getItemTags('com_agdetagsearchs.agdetagsearch', $item->id);
		}

		return $items;
	}

	/**
	 * Method to get a JDatabaseQuery object for retrieving the data set from a database.
	 *
	 * @return  JDatabaseQuery   A JDatabaseQuery object to retrieve the data set.
	 *
	 * @since   1.6
	 */
	protected function getListQuery()
	{
		$groups = implode(',', JFactory::getUser()->getAuthorisedViewLevels());

		// Create a new query object.
		$db = $this->getDbo();
		$query = $db->getQuery(true);

		// Select required fields from the categories.
		$query->select($this->getState('list.select', 'a.*'))
			->from($db->quoteName('#__agdetagsearchs') . ' AS a')
			->where('a.access IN (' . $groups . ')');

		// Filter by category.
		if ($categoryId = $this->getState('category.id'))
		{
			// Group by subcategory
			if ($this->getState('category.group', 0))
			{
				$query->select('c.title AS category_title')
					->where('c.parent_id = ' . (int) $categoryId)
					->join('LEFT', '#__categories AS c ON c.id = a.catid')
					->where('c.access IN (' . $groups . ')');
			}
			else
			{
				$query->where('a.catid = ' . (int) $categoryId)
					->join('LEFT', '#__categories AS c ON c.id = a.catid')
					->where('c.access IN (' . $groups . ')');
			}

			// Filter by published category
			$cpublished = $this->getState('filter.c.published');

			if (is_numeric($cpublished))
			{
				$query->where('c.published = ' . (int) $cpublished);
			}
		}

		// Join over the users for the author and modified_by names.
		$query->select("CASE WHEN a.created_by_alias > ' ' THEN a.created_by_alias ELSE ua.name END AS author")
			->select("ua.email AS author_email")
			->join('LEFT', '#__users AS ua ON ua.id = a.created_by')
			->join('LEFT', '#__users AS uam ON uam.id = a.modified_by');

		// Filter by state
		$state = $this->getState('filter.state');

		if (is_numeric($state))
		{
			$query->where('a.state = ' . (int) $state);
		}

		// Do not show trashed links on the front-end
		$query->where('a.state != -2');

		// Filter by start and end dates.
		$nullDate = $db->quote($db->getNullDate());
		$nowDate = $db->quote(JFactory::getDate()->toSql());

		if ($this->getState('filter.publish_date'))
		{
			$query->where('(a.publish_up = ' . $nullDate . ' OR a.publish_up <= ' . $nowDate . ')')
				->where('(a.publish_down = ' . $nullDate . ' OR a.publish_down >= ' . $nowDate . ')');
		}

		// Filter by language
		if ($this->getState('filter.language'))
		{
			$query->where('a.language in (' . $db->quote(JFactory::getLanguage()->getTag()) . ',' . $db->quote('*') . ')');
		}

		// Filter by search in title
		$search = $this->getState('list.filter');

		if (!empty($search))
		{
			$search = $db->quote('%' . $db->escape($search, true) . '%');
			$query->where('(a.title LIKE ' . $search . ')');
		}

		// If grouping by subcategory, add the subcategory list ordering clause.
		if ($this->getState('category.group', 0))
		{
			$query->order(
				$db->escape($this->getState('category.ordering', 'c.lft')) . ' ' .
					$db->escape($this->getState('category.direction', 'ASC'))
			);
		}

		// Add the list ordering clause.
		$query->order(
			$db->escape($this->getState('list.ordering', 'a.ordering')) . ' ' .
				$db->escape($this->getState('list.direction', 'ASC'))
		);

		return $query;
	}

	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @param   string  $ordering   An optional ordering field.
	 * @param   string  $direction  An optional direction (asc|desc).
	 *
	 * @return  void
	 *
	 * @since   1.6
	 */
	protected function populateState($ordering = null, $direction = null)
	{
		$app = JFactory::getApplication();
		$params = JComponentHelper::getParams('com_agdetagsearchs');

		// List state information
		$limit = $app->getUserStateFromRequest('global.list.limit', 'limit', $app->get('list_limit'), 'uint');
		$this->setState('list.limit', $limit);

		$limitstart = $app->input->get('limitstart', 0, 'uint');
		$this->setState('list.start', $limitstart);

		// Optional filter text
		$this->setState('list.filter', $app->input->getString('filter-search'));

		$orderCol = $app->input->get('filter_order', 'ordering');

		if (!in_array($orderCol, $this->filter_fields))
		{
			$orderCol = 'ordering';
		}

		$this->setState('list.ordering', $orderCol);

		$listOrder = $app->input->get('filter_order_Dir', 'ASC');

		if (!in_array(strtoupper($listOrder), array('ASC', 'DESC', '')))
		{
			$listOrder = 'ASC';
		}

		$this->setState('list.direction', $listOrder);

		$id = $app->input->get('id', 0, 'int');
		$this->setState('category.id', $id);

		$user = JFactory::getUser();

		if ((!$user->authorise('core.edit.state', 'com_agdetagsearchs')) && (!$user->authorise('core.edit', 'com_agdetagsearchs')))
		{
			// Limit to published for people who can't edit or edit.state.
			$this->setState('filter.state', 1);

			// Filter by start and end dates.
			$this->setState('filter.publish_date', true);
		}

		$this->setState('filter.language', JLanguageMultilang::isEnabled());

		// Load the parameters.
		$this->setState('params', $params);
	}

	/**
	 * Method to get category data for the current category
	 *
	 * @return  object
	 *
	 * @since   1.5
	 */
	public function getCategory()
	{
		if (!is_object($this->_item))
		{
			$app = JFactory::getApplication();
			$menu = $app->getMenu();
			$active = $menu->getActive();
			$params = new Registry;

			if ($active)
			{
				$params->loadString($active->params);
			}

			$options = array();
			$options['countItems'] = $params->get('show_cat_num_links_cat', 1) || $params->get('show_empty_categories', 0);

			$categories = JCategories::getInstance('Agdetagsearchs', $options);
			$this->_item = $categories->get($this->getState('category.id', 'root'));

			if (is_object($this->_item))
			{
				$this->_children = $this->_item->getChildren();
				$this->_parent = false;

				if ($this->_item->getParent())
				{
					$this->_parent = $this->_item->getParent();
				}

				$this->_rightsibling = $this->_item->getSibling();
				$this->_leftsibling = $this->_item->getSibling(false);
			}
			else
			{
				$this->_children = false;
				$this->_parent = false;
			}
		}

		return $this->_item;
	}

	/**
	 * Get the parent category
	 *
	 * @return  mixed  An array of categories or false if an error occurs.
	 */
	public function getParent()
	{
		if (!is_object($this->_item))
		{
			$this->getCategory();
		}

		return $this->_parent;
	}

	/**
	 * Get the leftsibling (adjacent) categories.
	 *
	 * @return  mixed  An array of categories or false if an error occurs.
	 */
	public function &getLeftSibling()
	{
		if (!is_object($this->_item))
		{
			$this->getCategory();
		}

		return $this->_leftsibling;
	}

	/**
	 * Get the rightsibling (adjacent) categories.
	 *
	 * @return  mixed  An array of categories or false if an error occurs.
	 */
	public function &getRightSibling()
	{
		if (!is_object($this->_item))
		{
			$this->getCategory();
		}

		return $this->_rightsibling;
	}

	/**
	 * Get the child categories.
	 *
	 * @return  mixed  An array of categories or false if an error occurs.
	 */
	public function &getChildren()
	{
		if (!is_object($this->_item))
		{
			$this->getCategory();
		}

		return $this->_children;
	}

	/**
	 * Increment the hit counter for the category.
	 *
	 * @param   integer  $pk  Optional primary key of the category to increment.
	 *
	 * @return  boolean  True if successful; false otherwise and internal error set.
	 *
	 * @since   3.2
	 */
	public function hit($pk = 0)
	{
		$hitcount = JFactory::getApplication()->input->getInt('hitcount', 1);

		if ($hitcount)
		{
			$pk = (!empty($pk)) ? $pk : (int) $this->getState('category.id');
			$table = JTable::getInstance('Category', 'JTable');
			$table->load($pk);
			$table->hit($pk);
		}

		return true;
	}

	/**
	 * Method to get neighbour tags of a tag
	 *
	 * @param   integer  $tagid  Optional primary key of the category to increment.
	 *
	 * @access public
	 * @return array
	 */
	public function getTagdata($tagid)
	{
		$this->typesr = $this->getState('typesr');
		$this->language = $this->getState('language');

		$params = JComponentHelper::getParams('com_agdetagsearchs');
		$anyOrAll = true;

		$db = JFactory::getDbo();
		$jhelpertags = new JHelperTags;
		$tagquery = $jhelpertags->getTagItemsQuery(
			$tagid,
			$this->typesr,
			$includeChildren = false,
			$orderByOption = 'c.core_title',
			$orderDir = 'ASC',
			$anyOrAll,
			$this->language,
			$stateFilter = '1'
		);

		$db->setQuery($tagquery);
		$result = $db->loadObjectList();

		return $result;
	}

	/**
	 * Method to get agdetagsearch item data for the category
	 *
	 * @access public
	 * @return array
	 */
	public function getData()
	{
		// Prepare the data.
		// Compute the agdetagsearch slug & link url.
		$this->tagids = array();

		$app = JFactory::getApplication();

		$this->results = array();
		$this->resultSum = array();
		$this->resultSumUnique = array();

		$this->typesr = $this->getState('typesr');
		$this->language = $this->getState('language');
		$this->limit = $this->getState('limit');
		$this->agtagscolumnlimit = $this->getState('agtagscolumnlimit');

		$params = JComponentHelper::getParams('com_agdetagsearchs');

		// $anyOrAll = true;
		$anyOrAll = $params->get('andor', 1);

		$this->items = $this->getItems();

		foreach ($this->items as $item)
		{
			$item->slug = $item->alias ? ($item->id . ':' . $item->alias) : $item->id;
			$postvalue = 'agdetagsearchs_' . str_replace(' ', '', $item->alias);
			$this->tagids[] = $this->getState($postvalue);
			$item->tagids[$postvalue] = $this->getState($postvalue);
		}

		$this->uniqtagids = array();

		foreach ($this->tagids as $tagid)
		{
			if (is_array($tagid))
			{
				$this->uniqtagids = array_unique(array_merge($this->uniqtagids, $tagid));
			}
		}

		$db = JFactory::getDbo();
		$jhelpertags = new JHelperTags;

		/*
		 * @param   mixed    $tagId            Tag or array of tags to be matched
		 * @param   mixed    $typesr           Null, type or array of type aliases for content types to be included in the results
		 * @param   boolean  $includeChildren  True to include the results from child tags
		 * @param   string   $orderByOption    Column to order the results by
		 * @param   string   $orderDir         Direction to sort the results in
		 * @param   boolean  $anyOrAll         True to include items matching at least one tag, false to include
		 *                                     items all tags in the array.
		 * @param   string   $languageFilter   Optional filter on language. Options are 'all', 'current' or any string.
		 * @param   string   $stateFilter      Optional filtering on publication state, defaults to published or unpublished.
		 */
		$tagquery = $jhelpertags->getTagItemsQuery(
			$this->uniqtagids,
			$this->typesr,
			$includeChildren = false,
			$orderByOption = 'c.core_title',
			$orderDir = 'ASC',
			$anyOrAll,
			$this->language,
			$stateFilter = '1'
		);

		$db->setQuery($tagquery);
		$this->result = $db->loadObjectList();

		$this->_total = count($this->result);

		$this->_data = array();

		if ($this->getState('limit') > 0)
		{
			$this->_data = array_splice($this->result, $this->getState('limitstart'), $this->getState('limit'));
		}
		else
		{
			$this->_data = $this->result;
		}

		return $this->_data;
	}

	/**
	 * Method to get the total number of weblink items for the category
	 *
	 * @access  public
	 *
	 * @return  integer
	 */
	public function getTotal()
	{
		if ($this->_total == null)
		{
			return 0;
		}
		else
		{
			return $this->_total;
		}
	}

}
