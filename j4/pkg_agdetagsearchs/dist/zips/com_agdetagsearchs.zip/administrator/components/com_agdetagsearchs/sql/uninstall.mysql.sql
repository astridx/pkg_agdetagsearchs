DROP TABLE IF EXISTS `#__agdetagsearchs_details`;
